﻿/*
 * Created by SharpDevelop.
 * User: naoaki
 * Date: 2018/04/07
 * Time: 16:50
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace app6
{
	/// <summary>
	/// Description of CalDay.
	/// </summary>
	public partial class CalDay : UserControl
	{
		public PictureBox[] boxes;

		public CalDay()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
			this.boxes = new PictureBox[4];
    		this.SuspendLayout();
    		for (int i = 0; i < 4; i++)
    		{
    			this.boxes[i] = new PictureBox();
    			this.boxes[i].Width = 48;
    			this.boxes[i].Height = 48;
    			this.boxes[i].BackColor = Color.LightGray;
    			this.boxes[i].SizeMode = PictureBoxSizeMode.Zoom;
    			this.boxes[i].Location = new Point(4 + (i % 2) * 52, 2 + (i / 2) * 52);
        	}
			this.panel1.Controls.AddRange(this.boxes);
    		this.ResumeLayout(false);
		}
	}
}
