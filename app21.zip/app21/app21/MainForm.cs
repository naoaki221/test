﻿/*
 * Created by SharpDevelop.
 * User: naoaki
 * Date: 2018/04/09
 * Time: 16:35
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.Windows.Forms;
using Manina.Windows.Forms;

namespace app21
{
	/// <summary>
	/// Description of MainForm.
	/// </summary>
	public partial class MainForm : Form
	{
		private Form1 f1;
		private Form2 f2;
		private System.IO.FileInfo[] files;
		private List<string>[] thumbs;
		private string[] dirs = {
			@"C:\Users\naoaki\Desktop\datadir\tiff",
			@"C:\Users\naoaki\Desktop\datadir\tiff2"
		};
		private string dir = null;
		
		public MainForm()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
			f1 = new Form1();
			f2 = new Form2();
			
			for (int i = 0; i < 31; i++)
			{
				this.calMonth1.Days[i].button1.Click += new EventHandler(this.button_Click);
				for (int j = 0; j < 4; j ++) {
					this.calMonth1.Days[i].boxes[j].Click += new EventHandler(this.picture_Click);
				}
			}
			thumbs = new List<string>[31];
			
			this.calMonth1.button1.Click += this.prev_Click;
			this.calMonth1.button2.Click += this.next_Click;
			
			this.listBox1.Items.Add("1");
			this.listBox1.Items.Add("2");
			
			//this.load(@"C:\Users\naoaki\Desktop\datadir\tiff2");
			this.dir = dirs[0];
			this.load(this.dir);
		}
		
		private void load(string datadir)
		{
			for (int i = 0; i < 31; i ++) {
				thumbs[i] = new List<string>();
				for (int j = 0; j < 4; j ++) {
					//thumbs[i, j] = null;
					this.calMonth1.Days[i].boxes[j].Visible = false;
					this.calMonth1.Days[i].label1.Visible = false;
				}
			}

			System.IO.DirectoryInfo di = new System.IO.DirectoryInfo(datadir);
			files = di.GetFiles("*.tif", System.IO.SearchOption.AllDirectories);
			Array.Sort(files, (__f1, __f2) => __f1.LastWriteTime.CompareTo(__f2.LastWriteTime));

			this.myListView1.Items.Clear();
			this.myListView2.Items.Clear();
			
			foreach (System.IO.FileInfo f in files)	{
				ImageListViewItem it = new ImageListViewItem();
				it.FileName = f.FullName;
				this.myListView1.Items.Add(it);		
				this.myListView2.Items.Add(it);
			}
			
			DateTime dt = DateTime.Now;
			foreach (System.IO.FileInfo f in files) {
//				if (f.LastWriteTime.Year == dt.Year && f.LastWriteTime.Month == dt.Month) {
				if (f.LastWriteTime.Year == this.calMonth1.Year && f.LastWriteTime.Month == this.calMonth1.Month) {
					thumbs[f.LastWriteTime.Day].Add(f.FullName);
					int c = thumbs[f.LastWriteTime.Day].Count;
					if (c <= 4) {
						Bitmap bitmap = (Bitmap)Image.FromFile(f.FullName);
						bitmap.SelectActiveFrame(FrameDimension.Page, 0);
						this.calMonth1.Days[f.LastWriteTime.Day].boxes[c - 1].Image = bitmap;
						this.calMonth1.Days[f.LastWriteTime.Day].boxes[c - 1].Visible = true;
					} else {
						this.calMonth1.Days[f.LastWriteTime.Day].label1.Visible = true;
					}
				}
			}
		}
		
		private void button_Click(object sender, EventArgs e)
		{
			System.Windows.Forms.Button b = (System.Windows.Forms.Button)sender;
			for (int i = 0; i < 31; i++) {
				this.calMonth1.Days[i].button1.ForeColor = Color.Black;
			}
			b.ForeColor = Color.Red;

			//f2.tiffView1.load(thumbs[day][index]);
			f2.myListView1.Items.Clear();
			foreach (System.IO.FileInfo f in files)	{
				//DateTime dt = f.CreationTime;
				DateTime dt = f.LastWriteTime;
				if (dt.Year == this.calMonth1.Year && dt.Month == this.calMonth1.Month 
				    && dt.Day == ((int)b.Tag)) {
					ImageListViewItem it = new ImageListViewItem();
					it.FileName = f.FullName;
					f2.myListView1.Items.Add(it);
				}
			}
			f2.Show();
			f2.BringToFront();
		}

		private void picture_Click(object sender, EventArgs e)
		{
			PictureBox b = (PictureBox)sender;
			int _tag = (int)b.Tag;
			int day = _tag >> 2;
			int index = _tag & 3;

			for (int i = 0; i < 31; i++) {
				for (int j = 0; j < 4; j ++) {
					this.calMonth1.Days[i].boxes[j].BackColor = Color.LightGray;
				}
			}
			b.BackColor = Color.Red;

			f1.tiffView1.load(thumbs[day][index]);
			f1.Show();
			f1.BringToFront();
		}
		
		private void prev_Click(object sender, EventArgs e)
		{
			System.Windows.Forms.Button b = (System.Windows.Forms.Button)sender;
			this.calMonth1.Month -= 1;
			this.calMonth1.arrange_days();
			//this.load(@"C:\Users\naoaki\Desktop\datadir\tiff2");	
			this.load(this.dir);			
		}

		private void next_Click(object sender, EventArgs e)
		{
			System.Windows.Forms.Button b = (System.Windows.Forms.Button)sender;
			this.calMonth1.Month += 1;
			this.calMonth1.arrange_days();
			//this.load(@"C:\Users\naoaki\Desktop\datadir\tiff2");			
			this.load(this.dir);			
		}
		void MyListView1ItemDoubleClick(object sender, ItemClickEventArgs e)
		{
			//f1.tiffView1.load(thumbs[day][index]);
			f1.tiffView1.load(e.Item.FileName);
			f1.Show();
			f1.BringToFront();	
		}
		void MyListView2ItemDoubleClick(object sender, ItemClickEventArgs e)
		{
			f1.tiffView1.load(e.Item.FileName);
			f1.Show();
			f1.BringToFront();		
		}
		void ListBox1DoubleClick(object sender, EventArgs e)
		{
			dir = dirs[this.listBox1.SelectedIndex];
			this.load(dir);
		}
	}
	
	public class MyListView : ImageListView
	{
		public MyListView()
		{
			//this.SetRenderer(new MyRenderer(), true);
			//this.SetRenderer(new ImageListViewRenderers.TilesRenderer(), true);
		}
	}
	
}
