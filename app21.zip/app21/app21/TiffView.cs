﻿/*
 * Created by SharpDevelop.
 * User: naoaki
 * Date: 2018/04/07
 * Time: 22:38
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Imaging;
using System.Windows.Forms;

namespace app6
{
	/// <summary>
	/// Description of TiffView.
	/// </summary>
	public partial class TiffView : UserControl
	{
		private Bitmap bitmap = null;
		
		public TiffView()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
			listView1.SelectedIndexChanged += this.ListView1SelectedIndexChanged;
		}

		public void load(string filename)
		{
			bitmap = (Bitmap)Image.FromFile(filename);
			
			int num_of_pages = bitmap.GetFrameCount(FrameDimension.Page);
			
			listView1.Clear();
			imageList1.Images.Clear();
			for (int i = 0; i < num_of_pages; i ++) {
				ListViewItem it = new ListViewItem();
    			it.ImageIndex = i;
    			listView1.Items.Add(it);
			
				bitmap.SelectActiveFrame(FrameDimension.Page, i);
				
				float scale = Math.Min((float)256.0 / bitmap.Width, (float)256.0 / bitmap.Height);
				int scaleWidth = (int)(bitmap.Width * scale);
				int scaleHeight = (int)(bitmap.Height * scale);

				Bitmap resize_bitmap = new Bitmap(256, 256);
				Graphics g = Graphics.FromImage(resize_bitmap);
				g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
				//g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.NearestNeighbor;
				g.DrawImage(bitmap, 0, 0, scaleWidth, scaleHeight);
				g.Dispose();
				imageList1.Images.Add(resize_bitmap);

			}

			bitmap.SelectActiveFrame(FrameDimension.Page, 0);
			pictureBox1.Image = bitmap;
		}

		public void movepage(int page)
		{
			bitmap.SelectActiveFrame(FrameDimension.Page, page);
			pictureBox1.Image = bitmap;			
		}
		
		void ListView1SelectedIndexChanged(object sender, EventArgs e)
		{
			if (listView1.SelectedIndices.Count > 0)
				this.movepage(listView1.SelectedIndices[0]);
		}
		void ToolStripButton1Click(object sender, EventArgs e)
		{
			//pictureBox1.Image.RotateFlip(
		}

	}
}
