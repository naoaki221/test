﻿/*
 * Created by SharpDevelop.
 * User: naoaki
 * Date: 2018/04/07
 * Time: 16:59
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace app6
{
	/// <summary>
	/// Description of CalMonth.
	/// </summary>
	public partial class CalMonth : UserControl
	{
		public int Year = 2018;
		public int Month = 4;
		
		public CalDay[] Days;

		public CalMonth()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
			DoubleBuffered = true;
			
			this.Days = new CalDay[31];
    		this.SuspendLayout();
    		for (int i = 0; i < 31; i++)
    		{
    			this.Days[i] = new CalDay();
        		this.Days[i].Name = i.ToString();
        		this.Days[i].Tag = i;
    		    this.Days[i].button1.Text = (i + 1).ToString();
				this.Days[i].button1.Tag = i;
				for (int j = 0; j < 4; j ++) {
					this.Days[i].boxes[j].Tag = (i << 2) | j;
				}
				this.Days[i].Visible = false;
				
				this.Days[i].label1.Visible = false;
        	}
			this.Controls.AddRange(this.Days);
    		this.ResumeLayout(false);

    		//arrange_days(Month, Day);
    		arrange_days();
		}
		
		//private void arrange_days(int year, int month)
		public void arrange_days()
		{
			int year = this.Year;
			int month = this.Month;

 	  		this.SuspendLayout();
 			
			DateTime dt = new DateTime(year, month, 1, 1, 0, 1);
			int o = (int)dt.DayOfWeek;
			int days = DateTime.DaysInMonth(year, month);

    		for (int i = 0; i < 31; i++)
    		{
    			int x = (o + i) % 7;
    			int y = (o + i) / 7;
    			
    			this.Days[i].Location = new Point(x * 112, 32 + y * 152);
    			
				if (x == 0)
					this.Days[i].button1.BackColor = Color.Pink;
				else if (x == 6)
					this.Days[i].button1.BackColor = Color.DodgerBlue;
 				else
 					this.Days[i].button1.BackColor = SystemColors.Control;
    			if (i < days) {
    				this.Days[i].Visible = true;
    			} else {
    				this.Days[i].Visible = false;
    			}
    		}
     		this.ResumeLayout(false);
   		
    		Invalidate();
		}
	}
}
