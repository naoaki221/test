﻿/*
 * Created by SharpDevelop.
 * User: naoaki
 * Date: 2018/04/09
 * Time: 16:35
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace app21
{
	partial class MainForm
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		private System.Windows.Forms.MenuStrip menuStrip1;
		private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
		private System.Windows.Forms.ListBox listBox1;
		private System.Windows.Forms.TabControl tabControl1;
		private System.Windows.Forms.TabPage tabPage1;
		private app6.CalMonth calMonth1;
		private System.Windows.Forms.TabPage tabPage2;
		private app21.MyListView myListView1;
		private System.Windows.Forms.TabPage tabPage3;
		private app21.MyListView myListView2;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			this.menuStrip1 = new System.Windows.Forms.MenuStrip();
			this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.listBox1 = new System.Windows.Forms.ListBox();
			this.tabControl1 = new System.Windows.Forms.TabControl();
			this.tabPage1 = new System.Windows.Forms.TabPage();
			this.calMonth1 = new app6.CalMonth();
			this.tabPage2 = new System.Windows.Forms.TabPage();
			this.myListView1 = new app21.MyListView();
			this.tabPage3 = new System.Windows.Forms.TabPage();
			this.myListView2 = new app21.MyListView();
			this.menuStrip1.SuspendLayout();
			this.tabControl1.SuspendLayout();
			this.tabPage1.SuspendLayout();
			this.tabPage2.SuspendLayout();
			this.tabPage3.SuspendLayout();
			this.SuspendLayout();
			// 
			// menuStrip1
			// 
			this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
			this.fileToolStripMenuItem});
			this.menuStrip1.Location = new System.Drawing.Point(0, 0);
			this.menuStrip1.Name = "menuStrip1";
			this.menuStrip1.Size = new System.Drawing.Size(665, 24);
			this.menuStrip1.TabIndex = 0;
			this.menuStrip1.Text = "menuStrip1";
			// 
			// fileToolStripMenuItem
			// 
			this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
			this.exitToolStripMenuItem});
			this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
			this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
			this.fileToolStripMenuItem.Text = "File";
			// 
			// exitToolStripMenuItem
			// 
			this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
			this.exitToolStripMenuItem.Size = new System.Drawing.Size(93, 22);
			this.exitToolStripMenuItem.Text = "Exit";
			// 
			// listBox1
			// 
			this.listBox1.Dock = System.Windows.Forms.DockStyle.Left;
			this.listBox1.FormattingEnabled = true;
			this.listBox1.ItemHeight = 12;
			this.listBox1.Location = new System.Drawing.Point(0, 24);
			this.listBox1.Name = "listBox1";
			this.listBox1.Size = new System.Drawing.Size(151, 405);
			this.listBox1.TabIndex = 1;
			this.listBox1.DoubleClick += new System.EventHandler(this.ListBox1DoubleClick);
			// 
			// tabControl1
			// 
			this.tabControl1.Controls.Add(this.tabPage1);
			this.tabControl1.Controls.Add(this.tabPage2);
			this.tabControl1.Controls.Add(this.tabPage3);
			this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tabControl1.Location = new System.Drawing.Point(151, 24);
			this.tabControl1.Name = "tabControl1";
			this.tabControl1.SelectedIndex = 0;
			this.tabControl1.Size = new System.Drawing.Size(514, 405);
			this.tabControl1.TabIndex = 2;
			// 
			// tabPage1
			// 
			this.tabPage1.Controls.Add(this.calMonth1);
			this.tabPage1.Location = new System.Drawing.Point(4, 22);
			this.tabPage1.Name = "tabPage1";
			this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage1.Size = new System.Drawing.Size(506, 379);
			this.tabPage1.TabIndex = 0;
			this.tabPage1.Text = "Calender";
			this.tabPage1.UseVisualStyleBackColor = true;
			// 
			// calMonth1
			// 
			this.calMonth1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.calMonth1.Location = new System.Drawing.Point(3, 3);
			this.calMonth1.Name = "calMonth1";
			this.calMonth1.Size = new System.Drawing.Size(500, 373);
			this.calMonth1.TabIndex = 0;
			// 
			// tabPage2
			// 
			this.tabPage2.Controls.Add(this.myListView1);
			this.tabPage2.Location = new System.Drawing.Point(4, 22);
			this.tabPage2.Name = "tabPage2";
			this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage2.Size = new System.Drawing.Size(506, 379);
			this.tabPage2.TabIndex = 1;
			this.tabPage2.Text = "List";
			this.tabPage2.UseVisualStyleBackColor = true;
			// 
			// myListView1
			// 
			this.myListView1.ColumnHeaderFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this.myListView1.Columns.AddRange(new Manina.Windows.Forms.ImageListView.ImageListViewColumnHeader[] {
			new Manina.Windows.Forms.ImageListView.ImageListViewColumnHeader(Manina.Windows.Forms.ColumnType.Name, "File Name", 240, 0, true),
			new Manina.Windows.Forms.ImageListView.ImageListViewColumnHeader(Manina.Windows.Forms.ColumnType.DateCreated, "", 160, 1, true)});
			this.myListView1.Cursor = System.Windows.Forms.Cursors.Default;
			this.myListView1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.myListView1.GroupHeaderFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
			this.myListView1.Location = new System.Drawing.Point(3, 3);
			this.myListView1.Name = "myListView1";
			this.myListView1.PersistentCacheDirectory = "";
			this.myListView1.PersistentCacheSize = ((long)(100));
			this.myListView1.Size = new System.Drawing.Size(500, 373);
			this.myListView1.SortColumn = 1;
			this.myListView1.SortOrder = Manina.Windows.Forms.SortOrder.Ascending;
			this.myListView1.TabIndex = 0;
			this.myListView1.UseWIC = true;
			this.myListView1.View = Manina.Windows.Forms.View.Details;
			this.myListView1.ItemDoubleClick += new Manina.Windows.Forms.ItemDoubleClickEventHandler(this.MyListView1ItemDoubleClick);
			// 
			// tabPage3
			// 
			this.tabPage3.Controls.Add(this.myListView2);
			this.tabPage3.Location = new System.Drawing.Point(4, 22);
			this.tabPage3.Name = "tabPage3";
			this.tabPage3.Size = new System.Drawing.Size(506, 379);
			this.tabPage3.TabIndex = 2;
			this.tabPage3.Text = "Tile";
			this.tabPage3.UseVisualStyleBackColor = true;
			// 
			// myListView2
			// 
			this.myListView2.ColumnHeaderFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this.myListView2.Dock = System.Windows.Forms.DockStyle.Fill;
			this.myListView2.GroupHeaderFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
			this.myListView2.Location = new System.Drawing.Point(0, 0);
			this.myListView2.Name = "myListView2";
			this.myListView2.PersistentCacheDirectory = "";
			this.myListView2.PersistentCacheSize = ((long)(100));
			this.myListView2.Size = new System.Drawing.Size(506, 379);
			this.myListView2.TabIndex = 0;
			this.myListView2.UseWIC = true;
			this.myListView2.ItemDoubleClick += new Manina.Windows.Forms.ItemDoubleClickEventHandler(this.MyListView2ItemDoubleClick);
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(665, 429);
			this.Controls.Add(this.tabControl1);
			this.Controls.Add(this.listBox1);
			this.Controls.Add(this.menuStrip1);
			this.MainMenuStrip = this.menuStrip1;
			this.Name = "MainForm";
			this.Text = "app21";
			this.menuStrip1.ResumeLayout(false);
			this.menuStrip1.PerformLayout();
			this.tabControl1.ResumeLayout(false);
			this.tabPage1.ResumeLayout(false);
			this.tabPage2.ResumeLayout(false);
			this.tabPage3.ResumeLayout(false);
			this.ResumeLayout(false);
			this.PerformLayout();

		}
	}
}
