﻿/*
 * Created by SharpDevelop.
 * User: naoaki
 * Date: 2018/04/09
 * Time: 19:06
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Drawing;
using System.Windows.Forms;

namespace app21
{
	/// <summary>
	/// Description of Form2.
	/// </summary>
	public partial class Form2 : Form
	{
		private Form1 f1;

		public Form2()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
			f1 = new Form1();
		}
		void Form2FormClosing(object sender, FormClosingEventArgs e)
		{
			if (e.CloseReason == CloseReason.UserClosing)
			{
				e.Cancel = true;
				Hide();
			}	
		}
		void MyListView1ItemDoubleClick(object sender, Manina.Windows.Forms.ItemClickEventArgs e)
		{
			f1.tiffView1.load(e.Item.FileName);
			f1.Show();
			f1.BringToFront();			
		}
	}
}
